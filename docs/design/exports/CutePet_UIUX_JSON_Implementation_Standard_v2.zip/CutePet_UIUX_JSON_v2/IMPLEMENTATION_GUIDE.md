# Implementation Guide

## Design direction
Cute, warm, polished pastel glassmorphism. The pet remains the emotional focal point, while the dashboard avoids dense settings. Use consistent tokens and cards with restrained shadows and spacing.

## Recommended order
1. Audit current app architecture and screenshots; map existing functions to this specification.
2. Add shared design tokens and reusable layout/card primitives.
3. Redesign Home dashboard, preserving existing controls and state.
4. Compact notification card and pet attachment lifecycle.
5. Incrementally restyle Pet, Notifications, Modes, Mailbox, Connections and Settings.
6. Test Windows/macOS differences, privacy, DND, reduced motion, and fallback behavior.

## Compact notification contract
- Target width around 340px.
- Header: app icon, app label, emotion/status and timestamp.
- Title: one line; body preview: up to two lines.
- Actions: up to two; omit footer when not needed.
- Pet attaches to one corner and never occludes text or action controls.
- Animation sequence: approach -> attach -> peek/react -> rest -> release.
- Reduced motion disables expressive entrance motion; notification behavior still works.
- Content privacy mode must not leak hidden notification content into logs or mailbox.

## Guardrails
- Do not duplicate existing notification/audio/animation controllers.
- Do not remove or change integrations just to match the mockup.
- Keep business logic out of UI components.
- Ensure keyboard focus, scaling and contrast.
- Implement fallback cards when pet rendering or animation fails.
